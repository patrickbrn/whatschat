/*
 * ScorerTest.java
 *
 * Created on 2019-08-02
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import java.util.Arrays;
import java.util.List;

import org.assertj.core.internal.bytebuddy.build.ToStringPlugin;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class ScorerTest {

    @Test
    void getScoreOfFrameWithSimpleThrows_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithTwoThrows(3, 3));

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isEqualTo(6);
    }

    @Test
    void getScoreOfFrameAtIndex_IsStrike_followingSimpleThrows_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithTwoThrows(2, 3));

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isEqualTo(15);
    }

    @Test
    void getScoreOfFrameWhereStrike_whenNoFollowingFramesAvailable_isNull() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithStrike());

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isNull();
    }

    @Test
    void getScoreOfFrameWhereIsStrikeFollowingStrike_returnsNull() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isNull();
    }

    @Test
    void getScoreOfFrameAtWhereIsStrike_followingStrikeAndStrike_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isEqualTo(30);
    }

    @Test
    void getScoreOfFrame_withSimpleThrows_isCorrect() {
        final Scorer scorer = new Scorer();

        scorer.addFrame(createFrameWithTwoThrows(2, 2));
        scorer.addFrame(createFrameWithTwoThrows(4, 2));
        scorer.addFrame(createFrameWithTwoThrows(6, 3));

        assertThat(scorer.getScoreOfFrame(1).orElse(null)).isEqualTo(10);
    }

    @Test
    void getScoreOfFrame_WhereSpare_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithSpare());
        scorer.addFrame(createFrameWithTwoThrows(2, 3));

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isEqualTo(12);
    }

    @Test
    void getScoreOfFrameWhereStrike_FollowingFrameWithSimpleThrows_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithTwoThrows(1, 3));
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithTwoThrows(4, 4));

        assertThat(scorer.getScoreOfFrame(1).orElse(null)).isEqualTo(22); //1+3+10+4+4
    }

    @Test
    void getScoreOfFrameWithSpareFollowingStrikeAndSimpleThrows_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithSpare());
        scorer.addFrame(createFrameWithStrike());

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isEqualTo(20);
    }

    @Test
    void getScoresOfFrame_withSimpleThrowAndSpareAndStrikeAndStrikeAndSpareAndSimpleThrow_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithTwoThrows(3, 3));
        scorer.addFrame(createFrameWithSpare());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithSpare());
        scorer.addFrame(createFrameWithTwoThrows(3, 6));

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isEqualTo(6);
        assertThat(scorer.getScoreOfFrame(1).orElse(null)).isEqualTo(26);
        assertThat(scorer.getScoreOfFrame(2).orElse(null)).isEqualTo(51);
        assertThat(scorer.getScoreOfFrame(3).orElse(null)).isEqualTo(71);
        assertThat(scorer.getScoreOfFrame(4).orElse(null)).isEqualTo(84);
        assertThat(scorer.getScoreOfFrame(5).orElse(null)).isEqualTo(93);
    }

    @Test
    void getScoreOfSpare_whereNextFrameEmpty_isEmpty() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(createFrameWithSpare());

        assertThat(scorer.getScoreOfFrame(0)).isEmpty();
    }

    @Test
    void addFrame_allowsMax10Frames_throwsException() {
        final Scorer scorer = new Scorer();

        for (int i = 0; i < 9; i++) {
            scorer.addFrame(createFrameWithTwoThrows(3, 2));
        }

        final Frame lastFrame = new Frame();
        lastFrame.setLastFrame(true);
        lastFrame.addThrow(3);
        lastFrame.addThrow(3);

        scorer.addFrame(lastFrame);

        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                                                         () -> scorer.addFrame(new Frame(8, 2)));

        assertThat(ex.getMessage()).isEqualTo("No more Frames allowed!");
    }

    @Test
    void getScoreOfLastFrame_isCorrect() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(new Frame(6, 2));
        scorer.addFrame(new Frame(5, 5));
        scorer.addFrame(new Frame(8, 2));
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(new Frame(3, 1));

        final Frame lastFrame = new Frame();
        lastFrame.setLastFrame(true);
        lastFrame.addThrow(5);
        lastFrame.addThrow(5);
        lastFrame.addThrow(10);

        scorer.addFrame(lastFrame);

        //LastFrame
        assertThat(scorer.getScoreOfFrame(9).orElse(null)).isEqualTo(197);
    }

    @Test
    void getScoresOfWholeGame() {
        final Scorer scorer = new Scorer();
        scorer.addFrame(new Frame(6, 2));
        scorer.addFrame(new Frame(5, 5));
        scorer.addFrame(new Frame(8, 2));
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(createFrameWithStrike());
        scorer.addFrame(new Frame(3, 1));

        final Frame lastFrame = new Frame();
        lastFrame.setLastFrame(true);
        lastFrame.addThrow(5);
        lastFrame.addThrow(5);
        lastFrame.addThrow(10);

        scorer.addFrame(lastFrame);

        assertThat(scorer.getScoreOfFrame(0).orElse(null)).isEqualTo(8);
        assertThat(scorer.getScoreOfFrame(1).orElse(null)).isEqualTo(26);
        assertThat(scorer.getScoreOfFrame(2).orElse(null)).isEqualTo(46);
        assertThat(scorer.getScoreOfFrame(3).orElse(null)).isEqualTo(76);
        assertThat(scorer.getScoreOfFrame(4).orElse(null)).isEqualTo(106);
        assertThat(scorer.getScoreOfFrame(5).orElse(null)).isEqualTo(136);
        assertThat(scorer.getScoreOfFrame(6).orElse(null)).isEqualTo(159);
        assertThat(scorer.getScoreOfFrame(7).orElse(null)).isEqualTo(173);
        assertThat(scorer.getScoreOfFrame(8).orElse(null)).isEqualTo(177);

        //LastFrame
        assertThat(scorer.getScoreOfFrame(9).orElse(null)).isEqualTo(197);
    }

    @Test
    void addFrameAtSize9_shouldNotAllowSimpleFrame() {
        final Scorer scorer = new Scorer();

        for (int i = 0; i < 9; i++) {
            scorer.addFrame(createFrameWithTwoThrows(3, 2));
        }

        final IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                                                         () -> scorer.addFrame(new Frame(3, 3)));

        assertThat(ex.getMessage()).isEqualTo("Not marked as last frame!");
    }

    private static Frame createFrameWithSpare() {
        final Frame frame = new Frame();
        frame.addThrow(5);
        frame.addThrow(5);

        return frame;
    }

    private static Frame createFrameWithStrike() {
        final Frame frame = new Frame();
        frame.addThrow(10);
        return frame;
    }

    private static Frame createFrameWithTwoThrows(final int firstThrow, final int secondThrow) {
        final Frame frame = new Frame();
        frame.addThrow(firstThrow);
        frame.addThrow(secondThrow);

        return frame;
    }
}
