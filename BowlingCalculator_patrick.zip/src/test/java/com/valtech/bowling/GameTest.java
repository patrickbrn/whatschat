/*
 * GameTest.java
 *
 * Created on 2019-08-06
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.omg.CORBA.FREE_MEM;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.assertj.core.api.Assertions.from;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

public class GameTest {

    private static final String PLAYER_NAME = "Tom";
    private static final String GAME_NAME = "Game Test";

    @Test
    void addPlayerToGame() {
        final Game game = new Game(GAME_NAME);

        final Player player = new Player(PLAYER_NAME);
        game.addPlayer(player);

        assertThat(game.getPlayerList().get(0)).isEqualTo(player);
    }

    @Test
    void addPlayerToGame_allowMaxSixPlayers() {
        final Game game = new Game(GAME_NAME);

        for (int i = 0; i < 6; i++) {
            game.addPlayer(new Player(GAME_NAME + " " + i));
        }

        assertThrows(UnsupportedOperationException.class, () -> game.addPlayer(new Player("Seventh")));
    }

    @Test
    void setNameOfGame() {
        final Game game = new Game(GAME_NAME);

        assertThat(game.getName()).isEqualTo(GAME_NAME);
    }

    @Test
    void setPlayerList() {
        final Game game = new Game(GAME_NAME);
        final List<Player> playerList = Arrays.asList(new Player("name1"), new Player("name2"));
        game.setPlayerList(playerList);
        assertThat(game.getPlayerList()).containsAnyElementsOf(playerList);
    }

    @Test
    void setNameOfGame_bySetter() {
        final Game game = new Game(GAME_NAME);
        final String newName = "newName";

        game.setName(newName);
        assertThat(game.getName()).isEqualTo(newName);
    }

    @Test
    void getCurrentPlayer() {
        final Game game = createGameWithTwoPlayers();

        assertThat(game.getCurrentPlayer()).isEqualTo(0);
    }

    @Test
    void addFrameToPlayer() {
        final Game game = createGameWithTwoPlayers();

        final Frame expectedFrame = new Frame(2, 2);
        game.addFrameToPlayer(expectedFrame, 1);

        final Frame actualFrame = game.getPlayerList().get(1).getScorer().getFrames().get(0);
        assertThat(actualFrame).isEqualTo(expectedFrame);
    }

    @Test
    void getScoreOfPlayerOfFrame() {
        final Game game = createGameWithTwoPlayers();

        final Frame frame = new Frame(2, 2);
        game.addFrameToPlayer(frame, 0);

        assertThat(game.getScoreOfPlayer(0, 0).orElse(null)).isEqualTo(4);
    }

    @Test
    void addThrowToFirstPlayerReturnsCurrentPlayerSecond() {
        final Game game = createGameWithTwoPlayers();
        final Frame frame = new Frame(2, 3);
        final Frame spareFrame = new Frame(5, 5);

        game.addFrameToPlayer(frame, 0);

        assertThat(game.getCurrentPlayer()).isEqualTo(1);
    }

    @Test
    void gameFlow_checkIfGameIsOver() {
        final Game game = createGameWithTwoPlayers();

        for (int i = 0; i < 9; i++) {

            game.addFrameToPlayer(new Frame(10, 0), game.getCurrentPlayer());
            assertThat(game.getCurrentPlayer()).isEqualTo(1);
            game.addFrameToPlayer(new Frame(5, 2), game.getCurrentPlayer());
            assertThat(game.getCurrentPlayer()).isEqualTo(0);
        }

        final Frame lastFrame1 = createLastFrameWithThrows(3, 3, Optional.empty());
        final Frame lastFrame2 = createLastFrameWithThrows(5, 5, Optional.of(10));

        game.addFrameToPlayer(lastFrame1, game.getCurrentPlayer());
        game.addFrameToPlayer(lastFrame2, game.getCurrentPlayer());

        assertThat(game.isGameOver()).isTrue();
    }

    @Test
    void isGameOver_shouldBeFalse_whenNoFrameSizeLimitReached() {
        final Game game = createGameWithTwoPlayers();

        assertThat(game.isGameOver()).isFalse();
    }

    @Test
    void isGameOver_shouldBeFalse_whenOnePlayerReachedFrameSizeLimit() {
        final Game game = createGameWithTwoPlayers();

        for (int i = 0; i < 8; i++) {
            game.addFrameToPlayer(new Frame(4, 4), 0);
        }
        final Frame lastFrame = createLastFrameWithThrows(3, 3, Optional.empty());

        game.addFrameToPlayer(lastFrame, 0);
        assertThat(game.isGameOver()).isFalse();
    }

    @Test
    void addNotExistingPlayer_throwsException() {
        final Game game = createGameWithTwoPlayers();

        assertThrows(IllegalArgumentException.class, () -> game.addFrameToPlayer(new Frame(), 4));
    }

    private Frame createLastFrameWithThrows(final int first, final int second, final Optional<Integer> third) {
        final Frame lastFrame = new Frame();
        lastFrame.setLastFrame(true);
        lastFrame.addThrow(first);
        lastFrame.addThrow(second);

        third.ifPresent(lastFrame::addThrow);

        return lastFrame;
    }

    private Game createGameWithTwoPlayers() {
        final Game game = new Game(GAME_NAME);
        game.addPlayer(new Player("1"));
        game.addPlayer(new Player("2"));

        return game;
    }
}
