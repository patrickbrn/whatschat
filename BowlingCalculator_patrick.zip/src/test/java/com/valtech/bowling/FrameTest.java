/*
 * FrameTest.java
 *
 * Created on 2019-08-02
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import com.sun.javaws.exceptions.InvalidArgumentException;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class FrameTest {

    @Test
    void addSimplePointsOfTwoThrows_getSumIsCorrect() {
        final Frame frame = new Frame();
        frame.addThrow(3);
        frame.addThrow(5);

        assertThat(frame.getSum().orElse(null)).isEqualTo(8);
    }

    @Test
    void getSumIsEmtpy_whenIsStrike() {
        final Frame frame = new Frame();
        frame.addThrow(10);

        assertThat(frame.getSum()).isEmpty();
    }

    @Test
    void getSumIsEmpty_whenIsSpare() {
        final Frame frame = new Frame();
        frame.addThrow(0);
        frame.addThrow(10);

        assertThat(frame.getSum()).isEmpty();
    }

    @Test
    void getSumShouldReturnEmpty_whenNoThrowsAdded() {
        final Frame frame = new Frame();

        assertThat(frame.getSum()).isEmpty();
    }

    @Test
    void addSimpleThrow_shouldNotAllowValueHigherTen() {
        final Frame frame = new Frame();

        final IllegalArgumentException valueMaxTenException = assertThrows(IllegalArgumentException.class, () -> {
            frame.addThrow(11);
        });
        assertThat(valueMaxTenException.getMessage()).isEqualTo("Point should not be greater than 10!");
    }

    @Test
    void addSimpleThrow_shouldNotAllowValuesUnderZero() {
        final Frame frame = new Frame();

        final IllegalArgumentException valueAtLeast0Ex = assertThrows(IllegalArgumentException.class, () -> {
            frame.addThrow(-1);
        });

        assertThat(valueAtLeast0Ex.getMessage()).isEqualTo("Point should not be smaller than 0!");
    }

    @Test
    void addSimpleThrows_shouldNotAllowMoreThan2Throws() {
        final Frame frame = new Frame();
        frame.addThrow(0);
        frame.addThrow(1);

        final IllegalArgumentException moreThanTwoThrowsEx = assertThrows(IllegalArgumentException.class, () -> {
            frame.addThrow(2);
        });

        assertThat(moreThanTwoThrowsEx.getMessage()).isEqualTo("No throws allowed");
    }

    @Test
    void doStrike_shouldNotBeSpare_whenIsSimpleFrame() {
        final Frame frame = new Frame();
        frame.addThrow(10);

        assertThat(frame.isSpare()).isFalse();
    }

    @Test
    void addStrikeThrow_shouldAllowJustOneThrow_whenRegularFrame() {
        final Frame frame = new Frame();
        frame.addThrow(10);

        final IllegalArgumentException illegalArgumentException = assertThrows(IllegalArgumentException.class, () -> {
            frame.addThrow(2);
        });

        assertThat(illegalArgumentException.getMessage()).isEqualTo("No throws allowed");
    }

    @Test
    void addThrowsAllowedFalse_WhenStrike() {
        final Frame frame = new Frame();
        frame.addThrow(10);

        assertThat(frame.isAddThrowAllowed()).isFalse();
    }

    @Test
    void addThrowsNotAllowed_whenTwoThrowsDone() {
        final Frame frame = new Frame();
        frame.addThrow(5);
        frame.addThrow(3);

        assertThat(frame.isAddThrowAllowed()).isFalse();
    }

    @Test
    void isStrike_whenFirstThrowIs10() {
        final Frame frame = new Frame();
        frame.addThrow(10);

        assertThat(true).isEqualTo(frame.isStrike());
    }

    @Test
    void isNotStrike_whenSecondThrowIs10() {
        final Frame frame = new Frame();
        frame.addThrow(0);
        frame.addThrow(10);

        assertThat(false).isEqualTo(frame.isStrike());
    }

    @Test
    void isSpare_whenTwoThrowsAreSum10() {
        final Frame frame = new Frame();
        frame.addThrow(5);
        frame.addThrow(5);

        assertThat(true).isEqualTo(frame.isSpare());
    }

    @Test
    void isNotSpare_whenTwoSimpleThrows() {
        final Frame frame = new Frame();
        frame.addThrow(2);
        frame.addThrow(5);

        assertThat(false).isEqualTo(frame.isSpare());
    }

    @Test
    void twoThrows_cannotBeGreaterTen() {
        final Frame frame = new Frame();
        frame.addThrow(2);

        final IllegalArgumentException valueTooHighEx = assertThrows(IllegalArgumentException.class,
                                                                     () -> frame.addThrow(10));

        assertThat(valueTooHighEx.getMessage()).isEqualTo("Value too high!");
    }

    @Test
    void getSumIsEmpty_whenNoThrowsAdded() {
        final Frame frame = new Frame();

        assertThat(frame.getSum()).isEmpty();
    }

    @Test
    void getThrownPoints_containsCorrectValues() {
        final Frame frame = new Frame();
        frame.addThrow(4);
        frame.addThrow(3);

        assertThat(frame.getThrowedPoints()).containsExactly(4, 3);
    }

    @Test
    void addSimpleThrow_allowedJust2Times_whenLastFrameTrue() {
        final Frame frame = new Frame(3, 3);
        frame.setLastFrame(true);

        final IllegalArgumentException valueTooHighEx = assertThrows(IllegalArgumentException.class,
                                                                     () -> frame.addThrow(10));

        assertThat(valueTooHighEx.getMessage()).isEqualTo("No throws allowed");
    }

    @Test
    void addStrikeThrow_allowJust3Times_whenLastFrameTrue() {
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(10);
        frame.addThrow(5);

        assertThat(frame.isAddThrowAllowed()).isTrue();
        frame.addThrow(5);
        assertThat(frame.isAddThrowAllowed()).isFalse();
    }

    @Test
    void addStrikeThrow_allowSecondStrike_whenLastFrame() {
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(10);
        frame.addThrow(10);

        assertThat(frame.isAddThrowAllowed()).isTrue();
    }

    @Test
    void addStrikeThrow_allowThreeStrikes_whenLastFrame() {
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(10);
        frame.addThrow(10);
        frame.addThrow(10);

        assertThat(frame.isAddThrowAllowed()).isFalse();
    }

    @Test
    void addSpareThrow_allowThreeThrows_whenLastFrame() {
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(5);
        frame.addThrow(5);

        assertThat(frame.isAddThrowAllowed()).isTrue();
    }

    @Test
    void getSumOfLastFrame_whenTwoSimpleThrow(){
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(3);
        frame.addThrow(2);

        assertThat(frame.getSum().orElse(null)).isEqualTo(5);
    }

    @Test
    void getSumOfLastFrame_whenSpare(){
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(5);
        frame.addThrow(5);
        frame.addThrow(5);

        assertThat(frame.getSum().orElse(null)).isEqualTo(15);
    }

    @Test
    void getSumOfLastFrame_whenStrike(){
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(10);
        frame.addThrow(10);
        frame.addThrow(10);

        assertThat(frame.getSum().orElse(null)).isEqualTo(30);
    }

    @Test
    void isSpareWhenLastFrame_whenTwoLastThrowsAre10(){
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(10);
        frame.addThrow(5);
        frame.addThrow(5);

        assertThat(frame.getSum().orElse(null)).isEqualTo(20);
        assertThat(frame.isSpare()).isTrue();
    }

    @Test
    void isStrikeWhenLastFrameAndwhenIsSpareFollowingStrike() {
        final Frame frame = new Frame();
        frame.setLastFrame(true);
        frame.addThrow(5);
        frame.addThrow(5);
        frame.addThrow(10);

        assertThat(frame.getSum().orElse(null)).isEqualTo(20);
        assertThat(frame.isSpare()).isTrue();
        assertThat(frame.isStrike()).isTrue();

    }

    @Test
    void toStringTest(){
        final Frame frame = new Frame();
        frame.addThrow(3);
        frame.addThrow(2);
        final String frameString = "Frame{throwedPoints=[3, 2], lastFrame=false}";

        assertThat(frame.toString()).isEqualTo(frameString);

    }
}
