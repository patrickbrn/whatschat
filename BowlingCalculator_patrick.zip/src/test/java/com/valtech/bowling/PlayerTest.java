/*
 * PlayerTest.java
 *
 * Created on 2019-08-06
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

public class PlayerTest {

    private static final String PLAYER_NAME = "Tom";

    @Test
    void scorerOfPlayerIsSet(){
        final Player player = new Player(PLAYER_NAME);

        final Frame frame = new Frame(2, 2);
        player.getScorer().addFrame(frame);

        assertThat(player.getScorer().getFrames().get(0)).isEqualTo(frame);
    }

    @Test
    void setNameOfPlayerByConstructor(){
        final Player player = new Player(PLAYER_NAME);

        assertThat(player.getName()).isEqualTo(PLAYER_NAME);
    }

    @Test
    void setNameOfPlayerBySetter(){
        final Player player = new Player(PLAYER_NAME);
        final String newName = "Tommy";
        player.setName(newName);
        assertThat(player.getName()).isEqualTo(newName);
    }

    @Test
    void toStringTest() {
        final Player player = new Player(PLAYER_NAME);
        final String playerString = "Player{scorer=Scorer{frames=[]}, name='Tom'}";

        assertThat(player.toString()).isEqualTo(playerString);



    }




}
