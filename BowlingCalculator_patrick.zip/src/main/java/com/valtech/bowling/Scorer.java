/*
 * Scorer.java
 *
 * Created on 2019-08-02
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

public class Scorer {

    private final List<Frame> frames = new ArrayList<>();

    public void addFrame(final Frame frame) {

        if (frames.size() == 10) {
            throw new IllegalArgumentException("No more Frames allowed!");
        }
        if(frames.size() == 9 && !frame.isLastFrame()) {
            throw new IllegalArgumentException("Not marked as last frame!");
        }

        frames.add(frame);
    }

    public Optional<Integer> getScoreOfFrame(final int index) {

        Frame frame;
        final AtomicInteger sum = new AtomicInteger(0);

        for (int currIndex = 0; currIndex <= index; currIndex++) {
            frame = frames.get(currIndex);

            if (frame.isLastFrame()) {
                return Optional.of(sum.addAndGet(frame.getSum().orElse(null)));
            }

            final Optional<Integer> sumOfFrame;

            if (frame.isStrike()) {
                sumOfFrame = getSumOfStrikeFrame(currIndex).map(sum::addAndGet);
            } else if (frame.isSpare()) {
                sumOfFrame = getSumOfSpareFrame(currIndex).map(sum::addAndGet);
            } else {
                sumOfFrame = Optional.of(sum.addAndGet(frame.getSum().orElse(null)));
            }
            if (!sumOfFrame.isPresent()) {
                return Optional.empty();
            }
        }

        return Optional.of(sum.get());
    }

    public List<Frame> getFrames() {
        return frames;
    }

    private Optional<Integer> getSumOfSpareFrame(final int index) {
        if (frameExists(index + 1)) {
            return Optional.of(frames.get(index + 1).getThrowedPoints().get(0) + 10);
        }

        return Optional.empty();
    }

    private Optional<Integer> getSumOfStrikeFrame(int index) {
        Frame nextFrame;

        if (frameExists(index + 1)) {
            nextFrame = frames.get(index + 1);
            if (!nextFrame.isStrike()) {
                return Optional.of(getSumOfFrame(nextFrame) + 10);
            } else if (frameExists(index + 2)) {
                nextFrame = frames.get(index + 2);
                return Optional.of(20 + nextFrame.getThrowedPoints().get(0));
            }
        }
        return Optional.empty();
    }

    private static Integer getSumOfFrame(final Frame frame) {

        return frame.getThrowedPoints().get(0) + frame.getThrowedPoints().get(1);
    }

    private boolean frameExists(final int position) {
        return position < frames.size();
    }

    @Override
    public String toString() {
        return "Scorer{" +
               "frames=" + frames +
               '}';
    }
}
