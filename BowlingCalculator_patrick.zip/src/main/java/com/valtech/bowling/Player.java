/*
 * Player.java
 *
 * Created on 2019-08-06
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;


public class Player {

    private final Scorer scorer = new Scorer();
    private String name;

    public Player(final String name) {
        this.name = name;
    }

    public Scorer getScorer() {
        return scorer;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Player{" +
               "scorer=" + scorer +
               ", name='" + name + '\'' +
               '}';
    }
}
