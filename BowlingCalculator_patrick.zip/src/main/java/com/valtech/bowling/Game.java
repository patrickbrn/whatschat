/*
 * Game.java
 *
 * Created on 2019-08-06
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Game {

    private List<Player> playerList = new ArrayList<>();
    private String name;

    public Game(final String name) {
        this.name = name;
    }

    public void addPlayer(final Player player) {
        if (playerList.size() == 6) {
            throw new UnsupportedOperationException("No more players allowed for this game");
        }
        playerList.add(player);
    }

    public List<Player> getPlayerList() {
        return playerList;
    }

    public void setPlayerList(final List<Player> playerList) {
        this.playerList = playerList;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public int getCurrentPlayer() {
        int lowestSize = 11;
        int playerIndex = 0;

        for (int i = 0; i < playerList.size(); i++) {
            final int frameSize = playerList.get(i).getScorer().getFrames().size();
            if (frameSize < lowestSize) {
                lowestSize = frameSize;
                playerIndex = i;
            }
        }
        return playerIndex;
    }

    public void addFrameToPlayer(final Frame frame, final int playerIndex) {

        if (!playerExists(playerIndex)) {
            throw new IllegalArgumentException("Player " + playerIndex + " does not exists");
        }
        playerList.get(playerIndex).getScorer().addFrame(frame);
    }

    public Optional<Integer> getScoreOfPlayer(final int playerIndex, final int frameIndex) {
        final Player player = playerList.get(playerIndex);

        return player.getScorer().getScoreOfFrame(frameIndex);
    }

    private boolean playerExists(final int index) {
        return index < playerList.size();
    }

    public boolean isGameOver() {
        boolean isDone = false;


        for (final Player player : playerList) {
             isDone = !(player.getScorer().getFrames().size() != 10)  ;
        }

        return isDone;
    }
}
