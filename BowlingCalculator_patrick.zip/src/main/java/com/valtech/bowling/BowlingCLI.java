/*
 * BowlingCLI.java
 *
 * Created on 2019-08-06
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import java.util.Scanner;

@Deprecated
public class BowlingCLI {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        final Game game = new Game("New Game");

        System.out.println("*************** Welcome to the Bowling Calculator! ***************");
        System.out.println("Player 1:");

        game.addPlayer(new Player(scanner.next()));
        System.out.println("Player 2:");
        game.addPlayer(new Player(scanner.next()));

        System.out.println("More Players to add y/n?");

        while (scanner.next().charAt(0) == 'y') {
            System.out.println("More Players to add y/n?");

            System.out.println("Player " + game.getPlayerList().size() + 1 + " ");
            game.addPlayer(new Player(scanner.next()));
        }

        //todo
    }
}
