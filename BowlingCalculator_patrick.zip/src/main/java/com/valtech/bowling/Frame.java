/*
 * Frame.java
 *
 * Created on 2019-08-02
 *
 * Copyright (C) 2019 Volkswagen AG, All rights reserved.
 */

package com.valtech.bowling;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Frame {

    private final List<Integer> throwedPoints = new ArrayList<>();
    private boolean lastFrame;

    public Frame() {
    }

    public Frame(final int firstThrow, final int secondThrow) {
        addThrow(firstThrow);
        addThrow(secondThrow);
    }

    public void addThrow(final int points) {

        if (!isAddThrowAllowed() && points != 0) {
            throw new IllegalArgumentException("No throws allowed");
        }

        if (points > 10) {
            throw new IllegalArgumentException("Point should not be greater than 10!");
        }

        if (points < 0) {
            throw new IllegalArgumentException("Point should not be smaller than 0!");
        }

        if (!throwedPoints.isEmpty()) {
            if ((!isStrike() & !isLastFrame()) || (!isSpare() & !isLastFrame())) {
                if (((throwedPoints.get(0) + points) > 10)) {
                    throw new IllegalArgumentException("Value too high!");
                }
            }
        }
        throwedPoints.add(points);
    }

    public boolean isAddThrowAllowed() {

        if ((isLastFrame() && isStrike()) || (isLastFrame() && isSpare())) {
            return (throwedPoints.size() < 3);
        }
        return (throwedPoints.size() < 2) && !isStrike();
    }

    public Optional<Integer> getSum() {

        if (isLastFrame()) {
            if (isSpare() || isStrike()) {
                return Optional.of(throwedPoints.get(0) + throwedPoints.get(1) + throwedPoints.get(2));
            }
        }
        if ((!throwedPoints.isEmpty() && !isStrike()) && !isSpare()) {
            return Optional.of(throwedPoints.get(0) + throwedPoints.get(1));
        }

        return Optional.empty();
    }

    public boolean isStrike() {
        boolean strike = false;

        if (!throwedPoints.isEmpty()) {
            strike = throwedPoints.get(0) == 10;
        }

        if (isLastFrame() && (throwedPoints.size() > 2)) {
            strike = strike || (throwedPoints.get(2) == 10);
        }

        return strike;
    }

    public boolean isSpare() {
        boolean simpleSpare;

        if (throwedPoints.size() > 1) {
            simpleSpare = (throwedPoints.get(0) + throwedPoints.get(1)) == 10;

            if (isLastFrame()) {
                if (isStrike() && (throwedPoints.size() > 2)) {
                    return ((throwedPoints.get(1) + throwedPoints.get(2)) == 10) || simpleSpare;
                }
            }
            if (!isStrike()) {
                return simpleSpare;
            }
        }
        return false;
    }

    public List<Integer> getThrowedPoints() {
        return throwedPoints;
    }

    public boolean isLastFrame() {
        return lastFrame;
    }

    public void setLastFrame(final boolean lastFrame) {
        this.lastFrame = lastFrame;
    }

    @Override
    public String toString() {
        return "Frame{" +
               "throwedPoints=" + throwedPoints +
               ", lastFrame=" + lastFrame +
               '}';
    }
}
